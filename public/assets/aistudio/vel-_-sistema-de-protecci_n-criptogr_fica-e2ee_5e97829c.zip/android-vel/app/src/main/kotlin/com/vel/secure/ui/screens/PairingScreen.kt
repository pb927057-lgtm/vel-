package com.vel.secure.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vel.secure.domain.model.DeviceRole
import com.vel.secure.ui.theme.*

@Composable
fun PairingScreen(
    currentRole: DeviceRole,
    onPairingSuccess: () -> Unit,
    onCancel: () -> Unit
) {
    var step by remember { mutableStateOf(1) }
    var pairingCode by remember { mutableStateOf("VEL-7892-AUTH") }

    Scaffold(
        containerColor = VelBackgroundMain,
        topBar = {
            TopAppBar(
                title = { Text("Vinculación Criptográfica Mutua", color = VelTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Cancelar", tint = VelTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = VelSurface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(
                    text = if (currentRole == DeviceRole.CORE) "CORE: Autorización de Nuevo Terminal" else "Terminal: Enlace con CORE",
                    style = MaterialTheme.typography.titleLarge,
                    color = if (currentRole == DeviceRole.CORE) VelAccentCyan else VelPrimaryBlue
                )

                Text(
                    text = "El procedimiento requiere autenticación mutua, establecimiento ECDH P-256 de claves y aprobación explícita de CORE. No contiene claves privadas en el intercambio.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = VelTextSecondary
                )

                // Progreso de pasos
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, VelBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = VelSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (step >= 1) VelStatusSuccess else VelBorder
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("1. Generación de identidad efímera ECDH", color = VelTextPrimary)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (step >= 2) VelStatusSuccess else VelBorder
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("2. Verificación de huella criptográfica", color = VelTextPrimary)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (step >= 3) VelStatusSuccess else VelBorder
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("3. Derivación HKDF y aprobación de CORE", color = VelTextPrimary)
                        }
                    }
                }

                // Código o QR
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(VelSurfaceElevated, RoundedCornerShape(12.dp))
                        .border(1.dp, VelBorder, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Código de Un Solo Uso",
                            style = MaterialTheme.typography.labelSmall,
                            color = VelTextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = pairingCode,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = VelAccentCyan,
                            letterSpacing = 2.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Expira en 180 segundos",
                            style = MaterialTheme.typography.labelSmall,
                            color = VelStatusWarning
                        )
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        if (step < 3) {
                            step++
                        } else {
                            onPairingSuccess()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = VelPrimaryBlue),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (step < 3) "Avanzar Verificación (${step}/3)" else "Confirmar y Autorizar Terminal",
                        fontWeight = FontWeight.SemiBold
                    )
                }

                OutlinedButton(
                    onClick = onCancel,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = VelTextSecondary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Cancelar Vinculación")
                }
            }
        }
    }
}
