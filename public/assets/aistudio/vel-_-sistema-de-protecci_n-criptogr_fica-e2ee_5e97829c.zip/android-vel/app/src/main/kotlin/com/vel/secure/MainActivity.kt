package com.vel.secure

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.vel.secure.data.local.AuthorizedDeviceEntity
import com.vel.secure.domain.model.DeviceRole
import com.vel.secure.domain.model.ExecutionStatus
import com.vel.secure.ui.screens.*
import com.vel.secure.ui.theme.VelTheme
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VelTheme {
                var currentScreen by remember { mutableStateOf("WELCOME") }
                var deviceRole by remember { mutableStateOf(DeviceRole.UNCONFIGURED) }
                val deviceId = remember { UUID.randomUUID().toString() }

                var pairedCoreId by remember { mutableStateOf<String?>(null) }
                var isRevoked by remember { mutableStateOf(false) }
                var currentOpStatus by remember { mutableStateOf<ExecutionStatus?>(null) }

                var targetRevocationId by remember { mutableStateOf("") }

                val authorizedDevices = remember {
                    mutableStateListOf(
                        AuthorizedDeviceEntity(
                            deviceId = "term-48291a-sec",
                            deviceName = "Terminal Galaxy S24 (Propietario)",
                            role = "TERMINAL",
                            authorizationStatus = "AUTHORIZED",
                            pairedAtTimestamp = System.currentTimeMillis() - 86400000,
                            lastSeenTimestamp = System.currentTimeMillis(),
                            authTokenHash = "a4b5c6...",
                            publicKeyHex = "04ab34..."
                        )
                    )
                }

                when (currentScreen) {
                    "WELCOME" -> {
                        WelcomeScreen(
                            onContinue = {
                                currentScreen = if (deviceRole == DeviceRole.UNCONFIGURED) {
                                    "ROLE_SELECTION"
                                } else if (deviceRole == DeviceRole.CORE) {
                                    "CORE_HOME"
                                } else {
                                    "TERMINAL_HOME"
                                }
                            }
                        )
                    }

                    "ROLE_SELECTION" -> {
                        RoleSelectionScreen(
                            onRoleSelected = { selected ->
                                deviceRole = selected
                                currentScreen = if (selected == DeviceRole.CORE) "CORE_HOME" else "TERMINAL_HOME"
                            }
                        )
                    }

                    "CORE_HOME" -> {
                        CoreHomeScreen(
                            deviceId = deviceId,
                            serverConnected = true,
                            authorizedDevices = authorizedDevices,
                            onNavigateToPairing = { currentScreen = "PAIRING" },
                            onNavigateToRevocation = { targetId ->
                                targetRevocationId = targetId
                                currentScreen = "REVOCATION"
                            },
                            onNavigateToDiagnostics = { currentScreen = "DIAGNOSTICS" }
                        )
                    }

                    "TERMINAL_HOME" -> {
                        TerminalHomeScreen(
                            deviceId = deviceId,
                            pairedCoreId = pairedCoreId,
                            isRevoked = isRevoked,
                            revocationReason = if (isRevoked) "Revocado por CORE tras cambio de credencial maestra" else null,
                            channelConnected = true,
                            currentOpStatus = currentOpStatus,
                            onNavigateToPairing = { currentScreen = "PAIRING" },
                            onExecuteOperation = { opType ->
                                currentOpStatus = ExecutionStatus.PREPARING
                                // En ejecución real: cifra con AES-GCM, envía por WebSocket, espera respuesta firmada
                                currentOpStatus = ExecutionStatus.PENDING_CORE_CONFIRMATION
                                currentOpStatus = ExecutionStatus.EXECUTED_AND_CONFIRMED
                            },
                            onNavigateToDiagnostics = { currentScreen = "DIAGNOSTICS" }
                        )
                    }

                    "PAIRING" -> {
                        PairingScreen(
                            currentRole = deviceRole,
                            onPairingSuccess = {
                                if (deviceRole == DeviceRole.TERMINAL) {
                                    pairedCoreId = "core-master-001"
                                    isRevoked = false
                                } else {
                                    authorizedDevices.add(
                                        AuthorizedDeviceEntity(
                                            deviceId = "term-new-${UUID.randomUUID().toString().take(6)}",
                                            deviceName = "Nuevo Terminal Vinculado",
                                            role = "TERMINAL",
                                            authorizationStatus = "AUTHORIZED",
                                            pairedAtTimestamp = System.currentTimeMillis(),
                                            lastSeenTimestamp = System.currentTimeMillis(),
                                            authTokenHash = "b7c8d9...",
                                            publicKeyHex = "04cd56..."
                                        )
                                    )
                                }
                                currentScreen = if (deviceRole == DeviceRole.CORE) "CORE_HOME" else "TERMINAL_HOME"
                            },
                            onCancel = {
                                currentScreen = if (deviceRole == DeviceRole.CORE) "CORE_HOME" else "TERMINAL_HOME"
                            }
                        )
                    }

                    "REVOCATION" -> {
                        RevocationScreen(
                            targetTerminalId = targetRevocationId,
                            onConfirmRevocation = { targetId ->
                                val index = authorizedDevices.indexOfFirst { it.deviceId == targetId }
                                if (index != -1) {
                                    authorizedDevices[index] = authorizedDevices[index].copy(
                                        authorizationStatus = "REVOKED"
                                    )
                                }
                                isRevoked = true
                                currentScreen = "CORE_HOME"
                            },
                            onCancel = { currentScreen = "CORE_HOME" }
                        )
                    }

                    "DIAGNOSTICS" -> {
                        DiagnosticsScreen(
                            roleLabel = deviceRole.label,
                            deviceId = deviceId,
                            webSocketConnected = true,
                            lastConfirmedResult = "Ejecución confirmada y autenticada",
                            recentErrors = emptyList(),
                            onBack = {
                                currentScreen = if (deviceRole == DeviceRole.CORE) "CORE_HOME" else "TERMINAL_HOME"
                            }
                        )
                    }
                }
            }
        }
    }
}
