package com.vel.secure.transport

import com.vel.secure.domain.model.EncryptedEnvelope
import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.websocket.*
import io.ktor.websocket.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

sealed class RelayConnectionState {
    object Disconnected : RelayConnectionState()
    object Connecting : RelayConnectionState()
    data class Connected(val relayEndpoint: String) : RelayConnectionState()
    data class Error(val message: String) : RelayConnectionState()
}

class KtorWebSocketClient(
    private val relayUrl: String = "wss://relay.vel.secure/v1/relay"
) {
    private val client = HttpClient(CIO) {
        install(WebSockets) {
            pingInterval = 20_000
        }
    }

    private val _connectionState = MutableStateFlow<RelayConnectionState>(RelayConnectionState.Disconnected)
    val connectionState: StateFlow<RelayConnectionState> = _connectionState.asStateFlow()

    private var activeSession: DefaultClientWebSocketSession? = null

    suspend fun connect(deviceId: String, role: String, authToken: String) {
        _connectionState.value = RelayConnectionState.Connecting
        try {
            client.webSocket(urlString = "$relayUrl?deviceId=$deviceId&role=$role&auth=$authToken") {
                activeSession = this
                _connectionState.value = RelayConnectionState.Connected(relayUrl)

                for (frame in incoming) {
                    if (frame is Frame.Text) {
                        val text = frame.readText()
                        // Procesar sobre cifrado entrante
                    }
                }
            }
        } catch (e: Exception) {
            _connectionState.value = RelayConnectionState.Error("Fallo de conexión WebSocket: ${e.message}")
        } finally {
            _connectionState.value = RelayConnectionState.Disconnected
            activeSession = null
        }
    }

    suspend fun sendEncryptedEnvelope(envelope: EncryptedEnvelope): Boolean {
        val session = activeSession ?: return false
        return try {
            val jsonPayload = Json.encodeToString(envelope)
            session.send(Frame.Text(jsonPayload))
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun disconnect() {
        activeSession?.close(CloseReason(CloseReason.Codes.NORMAL, "Desconexión manual"))
        activeSession = null
        _connectionState.value = RelayConnectionState.Disconnected
    }
}
